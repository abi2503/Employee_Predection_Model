getwd()
setwd("/Users/abhisheksuresh/Desktop/Capstone_Project")
capstone_data<-read.csv("338_cert_proj_datasets_v3.0.csv")
capstone_backup<-capstone_data
View(capstone_data)
sum(is.na(capstone_data))
capstone<-capstone_data
summary(capstone)
capstone$left<-as.factor(capstone$left)

#Out of 14999 employees  11428 did not leave and  3571 left 
#Assumption is 1 means left and 0 means not left
capstone$left<-ifelse(capstone$left=='0',"no","yes")
capstone_left_data<-capstone[capstone$left=="yes",]
#We can use corrplot to visualize
install.packages("corrplot")
library(corrplot)
capstone_not_left_data<-capstone[capstone$left=="no",]
capstone_correlation<-capstone[,-c(7,9,10)]
cr<-cor(capstone_correlation)
corrplot(cr,type = 'lower')
View(capstone_correlation)
hist(capstone$number_project)

plot(capstone$number_project,capstone$last_evaluation)

hist(capstone$average_montly_hours)
hist(capstone_left_data$average_montly_hours)
hist(capstone_not_left_data$average_montly_hours)

hist(capstone$satisfaction_level)
hist(capstone_left_data$satisfaction_level)
hist(capstone_not_left_data$satisfaction_level)


hist(capstone$number_project)
hist(capstone_left_data$number_project)
hist(capstone_not_left_data$number_project)

hist(capstone$time_spend_company)
hist(capstone_left_data$time_spend_company)
hist(capstone_not_left_data$time_spend_company)

plot(capstone$satisfaction_level,capstone$number_project)
plot(cap)


capstone$department<-as.factor(capstone$department)
capstone_not_left_data$department<-as.factor(capstone_left_data$department)
capstone$salary<-as.factor(capstone$salary)
summary(capstone_left_data)
capstone_left_data$department<-as.factor(capstone_left_data$department)
capstone_left_data$salary<-as.factor(capstone_left_data$salary)

table(capstone_left_data$salary)
table(capstone_not_left_data$salary)

summary(capstone)
View(capstone_left_data)

#Aggregate function

groupby_department <- aggregate(capstone$department, by = list(capstone$department), FUN=length)
View(groupby_department)
plot(groupby_department)

groupby_department_left<-aggregate(capstone_left_data$department,by = list(capstone_left_data$department),  FUN=length)
View(groupby_department_left)
plot(groupby_department_left)


groupby_department_left$PercentageLeft<-(groupby_department_left$x/groupby_department$x)*100

write.csv(groupby_department_left,file = "%Employee_Left_Department_Wise.csv")

#Let us create multiple histograms on one plot
install.packages('gridExtra')
library(gridExtra)

library(ggplot2)
a<-qplot(x=capstone$satisfaction_level,data=capstone,xlab = "Satisfaction_Level_Overall",ylab = "Frequency")
b<-qplot(x=capstone_not_left_data$satisfaction_level,data=capstone_not_left_data,xlab = "Satisfaction_Level_Employee_Not_Left",ylab = "Frequency")
c<-qplot(x=capstone_left_data$satisfaction_level,data=capstone_left_data,xlab = "Satisfaction_Level_Employee_Left",ylab = "Frequency")

grid.arrange(a,b,c)


a<-qplot(x=capstone$last_evaluation,data=capstone,xlab = "Last_Evaluation_Overall",ylab = "Frequency")
b<-qplot(x=capstone_not_left_data$last_evaluation,data=capstone_not_left_data,xlab = "Last_Evaluation_Employee_Not_Left",ylab = "Frequency")
c<-qplot(x=capstone_left_data$last_evaluation,data=capstone_left_data,xlab = "Last_Evaluation_Employee_Left",ylab = "Frequency")

grid.arrange(a,b,c)

a<-qplot(x=capstone$number_project,data=capstone,xlab = "Number_Of_Projects_Overall",ylab = "Frequency")
b<-qplot(x=capstone_not_left_data$number_project,data=capstone_not_left_data,xlab = "Number_Of_Projects_Employee_Not_Left",ylab = "Frequency")
c<-qplot(x=capstone_left_data$number_project,data=capstone_left_data,xlab = "Number_Of_Projects_Employee_Left",ylab = "Frequency")

grid.arrange(a,b,c)

a<-qplot(x=capstone$average_montly_hours,data=capstone,xlab = "Average_Monthly_Hours_Overall",ylab = "Frequency")
b<-qplot(x=capstone_not_left_data$average_montly_hours,data=capstone_not_left_data,xlab = "Average_Monthly_Hours_Employee_Not_Left",ylab = "Frequency")
c<-qplot(x=capstone_left_data$average_montly_hours,data=capstone_left_data,xlab = "Average_Monthly_Hours_Employee_Left",ylab = "Frequency")

grid.arrange(a,b,c)

a<-qplot(x=capstone$time_spend_company,data=capstone,xlab = "Time_Spend_In_Company_Overall",ylab = "Frequency")
b<-qplot(x=capstone_not_left_data$time_spend_company,data=capstone_not_left_data,xlab = "Time_Spend_In_Company_Employee_Not_Left",ylab = "Frequency")
c<-qplot(x=capstone_left_data$time_spend_company,data=capstone_left_data,xlab = "Time_Spend_In_Company_Employee_Left",ylab = "Frequency")

grid.arrange(a,b,c)
qplot(capstone$satisfaction_level,data = capstone, facets = capstone$left~capstone$salary)
qplot(capstone$number_project,data = capstone, facets = capstone$left~capstone$salary)
qplot(capstone$satisfaction_level,data = capstone, facets = capstone$left~capstone$department)

#Machine Learning  
#Decision Tree

install.packages("rpart")
library(rpart)
set.seed(100)
training_row_DT<-sample(1:nrow(capstone),0.7*nrow(capstone))
trainingdata_DT<-capstone[training_row_DT,]
testdata_DT<-capstone[-training_row_DT,]
model_DT<-rpart(trainingdata_DT$left~.,data=trainingdata_DT)
summary(model_DT)
plot(model_DT, margin=0.1)
text(model_DT, use.n = TRUE,pretty = TRUE, cex=0.8)
predvalues_DT<-predict(model_DT,newdata=testdata_DT,type = "class")


install.packages("caret")
library(caret)

install.packages("e1071")
library(e1071)
confusionMatrix(table(predvalues_DT, testdata_DT$left))


a <- cbind.data.frame(predvalues_DT, testdata_DT$left)
write.csv(a, "Decision_Tree.csv")
#Accuracy=97.2

#Random Forest
install.packages("randomForest")
library(randomForest)
set.seed(100)
training_row_RF<-sample(1:nrow(capstone),0.7*nrow(capstone))
trainingdata_RF<-capstone[training_row_RF,]
testdata_RF<-capstone[-training_row_RF,]
model_RF<-randomForest(trainingdata_RF$left~.,data=trainingdata_RF,ntree=100)
summary(model_RF)
plot(model_RF)
legend("right", colnames(model_RF$err.rate),col=1:4,cex=0.8,fill=1:4)


predvalues_RF<-predict(model_RF,newdata=testdata_RF,type = "class")
confusionMatrix(table(predvalues_RF, testdata_RF$left))

a <- cbind.data.frame(predvalues_RF, testdata_RF$left)
write.csv(a, "Random_Forest.csv")
#Accuracy=98.76


#Build naive bayes model

#Build a training and testing set
set.seed(4)

training_row_NB<-sample(1:nrow(capstone),0.7*nrow(capstone))
trainingdata_NB<-capstone[training_row_NB,]
testdata_NB<-capstone[-training_row_NB,]
model_NB<-naiveBayes(trainingdata_NB$left~. ,data = trainingdata_NB)
model_NB

predvalues_NB<-predict(model_NB,newdata = testdata_NB,type = "class")
predvalues_NB

confusionMatrix(table(predvalues_NB, testdata_NB$left))
a <- cbind.data.frame(predvalues_NB, testdata_NB$left)
write.csv(a, "Naive_Bayes.csv")
#Accuracy=79.91


#SVM

set.seed(4)

training_row_SVM<-sample(1:nrow(capstone),0.7*nrow(capstone))
trainingdata_SVM<-capstone[training_row_SVM,]
testdata_SVM<-capstone[-training_row_SVM,]


model_SVM<-svm(left~. ,data = trainingdata_SVM, kernel = "linear", cost = 0.1)
summary(model_SVM)

predvalues_SVM<-predict(model_SVM,newdata = testdata_SVM,type = "class")
confusionMatrix(table(predvalues_SVM, testdata_SVM$left))
a <- cbind.data.frame(predvalues_SVM, testdata_SVM$left)
write.csv(a, "SVM_Analysis.csv")
#78% Accuracy